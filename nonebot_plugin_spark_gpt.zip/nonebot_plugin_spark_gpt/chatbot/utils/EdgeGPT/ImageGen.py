# Open pull requests and issues at https://github.com/acheong08/BingImageCreator
from . import BingImageCreator

ImageGen = BingImageCreator.ImageGen

ImageGenAsync = BingImageCreator.ImageGenAsync

main = BingImageCreator.main

if __name__ == "__main__":
    main()
