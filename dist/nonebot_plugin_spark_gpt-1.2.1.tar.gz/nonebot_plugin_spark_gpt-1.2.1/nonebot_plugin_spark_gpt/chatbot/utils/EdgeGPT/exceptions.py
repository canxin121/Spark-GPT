class NotAllowedToAccess(Exception):
    pass
