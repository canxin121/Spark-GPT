class NotAllowedToAccess(Exception):
    pass
