from ..EdgeGPT import main as EdgeGPTMain


def main() -> None:
    EdgeGPTMain.main()


if __name__ == "__main__":
    main()
