from nonebot import logger

from plugins.nonebot_plugin_spark_gpt.common.common_func import reply_out
from .config import newbing_persistor, set_userdata
from .config import newbing_temper
from EdgeGPT import Chatbot, ConversationStyle


class Newbing_bot:
    async def __init__(self, event):
        self.chatbot = None
        self.current_userinfo, self.current_userdata = set_userdata(
            event=event, user_data_dict=newbing_temper.user_data_dict
        )
        if self.current_userdata.chatbot:
            chatbot = self.current_userdata.chatbot
        else:
            try:
                if len(newbing_persistor.proxy) > 0:
                    chatbot = await Chatbot.create(
                        cookies=newbing_persistor.cookie_path_,
                        proxy=newbing_persistor.proxy,
                    )
                else:
                    chatbot = await Chatbot.create(
                        cookies=newbing_persistor.cookie_path_
                    )
                self.current_userdata.chatbot = chatbot
            except FileNotFoundError:
                logger.warning("newbing cookie未配置,无法使用，跳过")
                raise
    async def refresh(self):
        retry = 3
        while(retry>0):
            try:
                if len(newbing_persistor.proxy) > 0:
                    self.chatbot = await Chatbot.create(
                    cookie_path=newbing_persistor.cookie_path_,
                    proxy=newbing_persistor.proxy,
                    )
                else:
                    self.chatbot = await Chatbot.create(
                        cookie_path=newbing_persistor.cookie_path_
                    )
                self.current_userdata.chatbot = self.chatbot
            except Exception as e :
                if retry>0:
                    retry +=1
                else:
                    raise e
                
    async def ask(self, question):
        chatbot = self.chatbot
        # 获取聊天模式
        chatmode = self.current_userdata.chatmode
        if chatmode == "1":
            style = ConversationStyle.creative
        elif chatmode == "2":
            style = ConversationStyle.balanced
        else:
            style = ConversationStyle.precise
        # 使用EdgeGPT进行ask询问
        retry = 3
        while(retry>0):
            try:
                if newbing_persistor.wss_link:
                    raw_json = await self.chatbot.ask(
                        prompt=question,
                        conversation_style=style,
                        wss_link=newbing_persistor.wss_link,
                    )
                else:
                    raw_json = await chatbot.ask(prompt=question, conversation_style=style)
            except Exception as e:
                if str(e) == "Update web page context failed":
                    await self.refresh()
                    try:
                        await self.ask(
                            question
                        )
                    except Exception as e:
                        raise e
                else:
                    if retry>0:
                        retry += 1
                    else:
                        logger.warning(str(e))
                        raise e
        reply = ""
        try:
            max_num = raw_json["item"]["throttling"]["maxNumUserMessagesInConversation"]
            now_num = raw_json["item"]["throttling"]["numUserMessagesInConversation"]
            reply = raw_json["item"]["messages"][1]["text"]
            if max_num == now_num:
                await self.refresh()
        except e:
            logger.warning("Newbing自动刷新对话出错")
            raise e
        
        try:
            is_offense = raw_json["item"]["messages"][0]["offense"]
            if is_offense == "Offensive" and not reply:
                raise Exception("你的询问太冒犯了,newbing拒绝回答")
            if "hiddenText" in raw_json["item"]["messages"][1] and not reply:
                raise Exception("你的询问太敏感了,newbing拒绝回答")
        except:
            raise Exception("未知错误，多次出错请尝试刷新对话")
        return raw_json


