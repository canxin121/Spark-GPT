# [Twitter Emoji (Twemoji)](https://twemoji.twitter.com/)
version: 14.0.2


Copyright Twitter Inc. and other contributors. 

Graphics licensed under CC-BY 4.0: https://creativecommons.org/licenses/by/4.0/
