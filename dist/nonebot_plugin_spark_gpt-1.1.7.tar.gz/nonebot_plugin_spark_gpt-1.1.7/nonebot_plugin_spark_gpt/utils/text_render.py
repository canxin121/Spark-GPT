from pathlib import Path

import markdown
from markdown.extensions.codehilite import CodeHiliteExtension
from markdown.extensions.tables import TableExtension
from mdx_math import MathExtension
from nonebot.utils import run_sync
from pygments.formatters import HtmlFormatter
from pygments.styles.xcode import XcodeStyle

from .imgkit import string_to_pic

ASSETS_PATH = Path(__file__).parent / "assets"
TEMP_PATH = Path(__file__).parent / "temp.jpeg"
TEMP_PATH.touch()
template_html = ""


class DisableHTMLExtension(markdown.Extension):
    def extendMarkdown(self, md):
        md.inlinePatterns.deregister("html")
        md.preprocessors.deregister("html_block")


extensions = [
    MathExtension(enable_dollar_delimiter=True),  # 开启美元符号渲染
    CodeHiliteExtension(
        linenums=False, css_class="highlight", noclasses=False, guess_lang=True
    ),  # 添加代码块语法高亮
    TableExtension(),
    "fenced_code",
]
md = markdown.Markdown(extensions=extensions)


@run_sync
def text_to_html(text: str) -> str:
    text = text.replace("\n", "  \n")
    content = md.convert(text)
    css_style = HtmlFormatter(style=XcodeStyle).get_style_defs(".highlight")

    content = f"<style>{css_style}</style>\n{content}"
    html = (
        template_html.replace("{path_texttoimg}", ASSETS_PATH.as_uri())
        .replace("{content}", content)
        .replace("{font_path_texttoimg}", (ASSETS_PATH / "PingFang.ttf").as_uri())
    )
    return html


async def text_to_pic(
        text: str,
        output_path: Path = TEMP_PATH,
        width: int = 2200,
        zoom: int = 2,
        quality: int = 100,
):
    html = await text_to_html(text)
    if not output_path.exists():
        output_path.touch()
    await string_to_pic(html, str(output_path.absolute()), width, zoom, quality)
    return output_path
