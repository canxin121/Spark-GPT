from pathlib import Path

from jinja2 import Environment, FileSystemLoader

from .imgkit import string_to_pic

env = Environment(loader=FileSystemLoader('assets'))
template = env.get_template('menu.html')
ASSETS_PATH = Path(__file__).parent / "assets"


async def menu_to_pic(menu: dict, path: str, width=500, ):
    html = template.render(headline="菜单", menu=menu, font_path_texttoimg=(ASSETS_PATH / "PingFang.ttf").as_uri())
    await string_to_pic(html, str(path), width)
    return path
