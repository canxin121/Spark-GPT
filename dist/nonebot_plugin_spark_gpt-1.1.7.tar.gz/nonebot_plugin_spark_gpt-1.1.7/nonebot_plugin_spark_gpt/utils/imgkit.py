from pathlib import Path

from charset_normalizer import from_bytes
from nonebot.utils import run_sync
from pygments.formatters import HtmlFormatter
from pygments.styles.xcode import XcodeStyle

import imgkit

ASSETS_PATH = Path(__file__).parent / "assets"


@run_sync
def string_to_pic(
        string: str, output_path: str, width: int = 2200, zoom: int = 2, quality: int = 100
):
    return imgkit.from_string(
        string,
        output_path,
        {
            "enable-local-file-access": "",
            "allow": ASSETS_PATH,
            "width": width,
            "enable-javascript": "",
            "zoom": zoom,
            "quality": quality,
            "quiet": "",
        },
        None,
        None,
        None,
        None,
    )


@run_sync
def file_to_pic(
        file_path: str,
        output_path: str,
        width: int = 2200,
        zoom: int = 2,
        quality: int = 100,
):
    return imgkit.from_file(
        file_path,
        output_path,
        output_path,
        {
            "enable-local-file-access": "",
            "allow": ASSETS_PATH,
            "width": width,
            "enable-javascript": "",
            "zoom": zoom,
            "quality": quality,
            "quiet": "",
        },
        None,
        None,
        None,
        None,
    )


@run_sync
def url_to_pic(
        url: str, output_path: str, width: int = 2200, zoom: int = 2, quality: int = 100
):
    return imgkit.from_url(
        url,
        output_path,
        output_path,
        {
            "enable-local-file-access": "",
            "allow": ASSETS_PATH,
            "width": width,
            "enable-javascript": "",
            "zoom": zoom,
            "quality": quality,
            "quiet": "",
        },
        None,
        None,
        None,
        None,
    )


with open(ASSETS_PATH / "template.html", "rb") as f:
    guessed_str = from_bytes(f.read()).best()
    if not guessed_str:
        raise ValueError("无法识别 Markdown 模板 template.html")

    # 获取 Pygments 生成的 CSS 样式
    highlight_css = HtmlFormatter(style=XcodeStyle).get_style_defs(".highlight")

    template_html = str(guessed_str).replace("{highlight_css}", highlight_css)
